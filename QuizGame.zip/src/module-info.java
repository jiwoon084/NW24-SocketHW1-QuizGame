module QuizGame {
	requires java.se;
}